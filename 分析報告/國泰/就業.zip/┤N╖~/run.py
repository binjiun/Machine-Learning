from flask import Flask
from flask import render_template
from flask import jsonify, send_from_directory, make_response
from flask import request, render_template, flash, redirect, url_for,session
import pandas as pd
import math

app = Flask(
__name__, static_url_path='/static',
static_folder='static/'

)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/information")
def home2():
    return render_template("information.html")


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5053,debug=True,threaded=True)