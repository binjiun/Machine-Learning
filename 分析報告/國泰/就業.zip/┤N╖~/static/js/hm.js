(function () {
    var h = {}, mt = {}, c = { id: "df6f78cfc7b28956736ab98287309c75", dm: ["bootstrapmb.com"], js: "tongji.baidu.com/hm-web/js/", etrk: [], cetrk: [], cptrk: [], icon: '', ctrk: [], vdur: 1800000, age: 31536000000, qiao: 0, pt: 0, spa: 0, aet: '', hca: 'D33BC64D665EEB99', ab: '0', v: 1, apps: '' }; var s = void 0, t = !0, u = null, v = !1; mt.cookie = {}; mt.cookie.set = function (e, a, b) { var f; b.D && (f = new Date, f.setTime(f.getTime() + b.D)); document.cookie = e + "=" + a + (b.domain ? "; domain=" + b.domain : "") + (b.path ? "; path=" + b.path : "") + (f ? "; expires=" + f.toGMTString() : "") + (b.dc ? "; secure" : "") }; mt.cookie.get = function (e) { return (e = RegExp("(^| )" + e + "=([^;]*)(;|$)").exec(document.cookie)) ? e[2] : u };
    mt.cookie.sb = function (e, a) { try { var b = "Hm_ck_" + +new Date; mt.cookie.set(b, "42", { domain: e, path: a, D: s }); var f = "42" === mt.cookie.get(b) ? "1" : "0"; mt.cookie.set(b, "", { domain: e, path: a, D: -1 }); return f } catch (d) { return "0" } };
    (function () {
        var e = mt.event; mt.lang = {}; mt.lang.j = function (a, b) { return "[object " + b + "]" === {}.toString.call(a) }; mt.lang.k = function (a) { return mt.lang.j(a, "Function") }; mt.lang.K = function (a) { return mt.lang.j(a, "Object") }; mt.lang.Xb = function (a) { return mt.lang.j(a, "Number") && isFinite(a) }; mt.lang.$ = function (a) { return mt.lang.j(a, "String") }; mt.lang.isArray = function (a) { return mt.lang.j(a, "Array") }; mt.lang.g = function (a) { return a.replace ? a.replace(/'/g, "'0").replace(/\*/g, "'1").replace(/!/g, "'2") : a }; mt.lang.trim =
            function (a) { return a.replace(/^\s+|\s+$/g, "") }; mt.lang.find = function (a, b, f) { if (mt.lang.isArray(a) && mt.lang.k(b)) for (var d = a.length, g = 0; g < d; g++)if (g in a && b.call(f || a, a[g], g)) return a[g]; return u }; mt.lang.Y = function (a, b) { return mt.lang.find(a, function (f) { return f === b }) != u }; mt.lang.filter = function (a, b) { var f = -1, d = 0, g = a == u ? 0 : a.length, l = []; if (mt.lang.k(b)) for (; ++f < g;) { var k = a[f]; b(k, f, a) && (l[d++] = k) } return l }; mt.lang.unique = function (a, b) {
                var f = a.length, d = a.slice(0), g, l; for (mt.lang.k(b) || (b = function (b,
                    f) { return b === f }); 0 < --f;) { l = d[f]; for (g = f; g--;)if (b(l, d[g])) { d.splice(f, 1); break } } return d
            }; mt.lang.Zb = function (a, b) { function f(b) { b = (d + d + Number(b).toString(2)).slice(-64); return [parseInt(b.slice(0, 32), 2), parseInt(b.slice(-32), 2)] } var d = "00000000000000000000000000000000", g = f(a), l = f(b); return parseInt((d + ((g[0] | l[0]) >>> 0).toString(2)).slice(-32) + (d + ((g[1] | l[1]) >>> 0).toString(2)).slice(-32), 2) }; mt.lang.extend = function (a) {
                for (var b = Array.prototype.slice.call(arguments, 1), f = 0; f < b.length; f++) {
                    var d = b[f],
                    g; for (g in d) Object.prototype.hasOwnProperty.call(d, g) && d[g] && (a[g] = d[g])
                } return a
            }; mt.lang.Pb = function (a) { function b(b, d) { var a = window.history, l = a[b]; a[b] = function () { l.apply(a, arguments); mt.lang.k(d) && d() } } b("pushState", function () { a() }); b("replaceState", function () { a() }); e.c(window, window.history.pushState ? "popstate" : "hashchange", function () { a() }) }; return mt.lang
    })(); mt.url = {}; mt.url.f = function (e, a) { var b = e.match(RegExp("(^|&|\\?|#)(" + a + ")=([^&#]*)(&|$|#)", "")); return b ? b[3] : u };
    mt.url.Ta = function (e) { return (e = e.match(/^(https?:\/\/)?([^\/\?#]*)/)) ? e[2].replace(/.*@/, "") : u }; mt.url.W = function (e) { return (e = mt.url.Ta(e)) ? e.replace(/:\d+$/, "") : e }; mt.url.qb = function (e) { var a = document.location.href, a = a.replace(/^https?:\/\//, ""); return 0 === a.indexOf(e) }; mt.url.rb = function (e, a) { e = "." + e.replace(/:\d+/, ""); a = "." + a.replace(/:\d+/, ""); var b = e.indexOf(a); return -1 < b && b + a.length === e.length };
    (function () {
        var e = mt.lang, a = mt.url; mt.d = {}; mt.d.Ma = function (b) { return document.getElementById(b) }; mt.d.Wb = function (b) {
            if (!b) return u; try {
                b = String(b); if (0 === b.indexOf("!HMCQ!")) return b; if (0 === b.indexOf("!HMCC!")) return document.querySelector(b.substring(6, b.length)); for (var f = b.split(">"), d = document.body, a = f.length - 1; 0 <= a; a--)if (-1 < f[a].indexOf("#")) { var l = f[a].split("#")[1]; (d = document.getElementById(l)) || (d = document.getElementById(decodeURIComponent(l))); f = f.splice(a + 1, f.length - (a + 1)); break } for (b =
                    0; d && b < f.length;) { var k = String(f[b]).toLowerCase(); if (!("html" === k || "body" === k)) { var a = 0, e = f[b].match(/\[(\d+)\]/i), l = []; if (e) a = e[1] - 1, k = k.split("[")[0]; else if (1 !== d.childNodes.length) { for (var n = 0, q = 0, p = d.childNodes.length; q < p; q++) { var m = d.childNodes[q]; 1 === m.nodeType && m.nodeName.toLowerCase() === k && n++; if (1 < n) return u } if (1 !== n) return u } for (n = 0; n < d.childNodes.length; n++)1 === d.childNodes[n].nodeType && d.childNodes[n].nodeName.toLowerCase() === k && l.push(d.childNodes[n]); if (!l[a]) return u; d = l[a] } b++ } return d
            } catch (w) { return u }
        };
        mt.d.ga = function (b, f) { var a = [], g = []; if (!b) return g; for (; b.parentNode != u;) { for (var l = 0, k = 0, e = b.parentNode.childNodes.length, n = 0; n < e; n++) { var q = b.parentNode.childNodes[n]; if (q.nodeName === b.nodeName && (l++, q === b && (k = l), 0 < k && 1 < l)) break } if ((e = "" !== b.id) && f) { a.unshift("#" + encodeURIComponent(b.id)); break } else e && (e = "#" + encodeURIComponent(b.id), e = 0 < a.length ? e + ">" + a.join(">") : e, g.push(e)), a.unshift(encodeURIComponent(String(b.nodeName).toLowerCase()) + (1 < l ? "[" + k + "]" : "")); b = b.parentNode } g.push(a.join(">")); return g };
        mt.d.Ya = function (b) { return (b = mt.d.ga(b, t)) && b.length ? String(b[0]) : "" }; mt.d.Xa = function (b) { return mt.d.ga(b, v) }; mt.d.Na = function (b) { var f; for (f = "A"; (b = b.parentNode) && 1 == b.nodeType;)if (b.tagName == f) return b; return u }; mt.d.Qa = function (b) { return 9 === b.nodeType ? b : b.ownerDocument || b.document }; mt.d.Va = function (b) {
            var f = { top: 0, left: 0 }; if (!b) return f; var a = mt.d.Qa(b).documentElement; "undefined" !== typeof b.getBoundingClientRect && (f = b.getBoundingClientRect()); return {
                top: f.top + (window.pageYOffset || a.scrollTop) -
                    (a.clientTop || 0), left: f.left + (window.pageXOffset || a.scrollLeft) - (a.clientLeft || 0)
            }
        }; mt.d.fc = function (b, f) { if (b) for (var a = b.childNodes, g = 0, l = a.length; g < l; g++) { var k = a[g]; if (k && 3 === k.nodeType) return a = k.textContent || k.innerText || k.nodeValue || "", k.textContent ? k.textContent = f : k.innerText ? k.innerText = f : k.nodeValue = f, a } }; mt.d.ec = function (b, a) { if (!b) return {}; var d = {}; a = a || {}; for (var g in a) a.hasOwnProperty(g) && a[g] !== s && (d[g] = b.getAttribute(g) || "", b.setAttribute(g, a[g])); return d }; mt.d.getAttribute = function (b,
            a) { var d = b.getAttribute && b.getAttribute(a) || u; if (!d && b.attributes && b.attributes.length) for (var g = b.attributes, l = g.length, k = 0; k < l; k++)g[k].nodeName === a && (d = g[k].nodeValue); return d }; mt.d.Ra = function (b) { var a = "document"; b.tagName !== s && (a = b.tagName); return a.toLowerCase() }; mt.d.$a = function (b) { var a = ""; b.textContent ? a = e.trim(b.textContent) : b.innerText && (a = e.trim(b.innerText)); a && (a = a.replace(/\s+/g, " ").substring(0, 255)); return a }; mt.d.Vb = function (b, f) {
                var d; e.$(b) && 0 === String(b).indexOf("!HMCQ!") ? (d =
                    String(b), d = a.f(document.location.href, d.substring(6, d.length))) : e.$(b) || (d = mt.d.Ra(b), "input" === d && f && ("button" === b.type || "submit" === b.type) ? d = e.trim(b.value) || "" : "input" === d && !f && "password" !== b.type ? d = e.trim(b.value) || "" : "img" === d ? (d = mt.d.getAttribute, d = d(b, "alt") || d(b, "title") || d(b, "src")) : d = "body" === d || "html" === d ? ["(hm-default-content-for-", d, ")"].join("") : mt.d.$a(b)); return String(d || "").substring(0, 255)
            }; (function () {
                (mt.d.ac = function () {
                    function a() { if (!a.L) { a.L = t; for (var f = 0, d = g.length; f < d; f++)g[f]() } }
                    function f() { try { document.documentElement.doScroll("left") } catch (d) { setTimeout(f, 1); return } a() } var d = v, g = [], l; document.addEventListener ? l = function () { document.removeEventListener("DOMContentLoaded", l, v); a() } : document.attachEvent && (l = function () { "complete" === document.readyState && (document.detachEvent("onreadystatechange", l), a()) }); (function () {
                        if (!d) if (d = t, "complete" === document.readyState) a.L = t; else if (document.addEventListener) document.addEventListener("DOMContentLoaded", l, v), window.addEventListener("load",
                            a, v); else if (document.attachEvent) { document.attachEvent("onreadystatechange", l); window.attachEvent("onload", a); var g = v; try { g = window.frameElement == u } catch (e) { } document.documentElement.doScroll && g && f() }
                    })(); return function (f) { a.L ? f() : g.push(f) }
                }()).L = v
            })(); return mt.d
    })(); mt.event = {}; mt.event.c = function (e, a, b) { e.attachEvent ? e.attachEvent("on" + a, function (a) { b.call(e, a) }) : e.addEventListener && e.addEventListener(a, b, v) };
    (function () {
        var e = mt.event; mt.e = {}; mt.e.nb = /msie (\d+\.\d+)/i.test(navigator.userAgent); mt.e.cookieEnabled = navigator.cookieEnabled; mt.e.javaEnabled = navigator.javaEnabled(); mt.e.language = navigator.language || navigator.browserLanguage || navigator.systemLanguage || navigator.userLanguage || ""; mt.e.Bb = (window.screen.width || 0) + "x" + (window.screen.height || 0); mt.e.colorDepth = window.screen.colorDepth || 0; mt.e.Za = function () {
            var a; a = a || document; return parseInt(window.pageYOffset || a.documentElement.scrollTop || a.body &&
                a.body.scrollTop || 0, 10)
        }; mt.e.bb = function () { var a = document; return parseInt(window.innerHeight || a.documentElement.clientHeight || a.body && a.body.clientHeight || 0, 10) }; mt.e.X = function () { return mt.e.Za() + mt.e.bb() }; mt.e.ta = 0; mt.e.cb = function () { var a = document; return parseInt(window.innerWidth || a.documentElement.clientWidth || a.body.offsetWidth || 0, 10) }; mt.e.orientation = 0; (function () {
            function a() {
                var a = 0; window.orientation !== s && (a = window.orientation); screen && (screen.orientation && screen.orientation.angle !==
                    s) && (a = screen.orientation.angle); mt.e.orientation = a; mt.e.ta = mt.e.cb()
            } a(); e.c(window, "orientationchange", a)
        })(); return mt.e
    })(); mt.z = {}; mt.z.parse = function (e) { return (new Function("return (" + e + ")"))() };
    mt.z.stringify = function () {
        function e(a) { /["\\\x00-\x1f]/.test(a) && (a = a.replace(/["\\\x00-\x1f]/g, function (a) { var f = b[a]; if (f) return f; f = a.charCodeAt(); return "\\u00" + Math.floor(f / 16).toString(16) + (f % 16).toString(16) })); return '"' + a + '"' } function a(a) { return 10 > a ? "0" + a : a } var b = { "\b": "\\b", "\t": "\\t", "\n": "\\n", "\f": "\\f", "\r": "\\r", '"': '\\"', "\\": "\\\\" }; return function (b) {
            switch (typeof b) {
                case "undefined": return "undefined"; case "number": return isFinite(b) ? String(b) : "null"; case "string": return e(b); case "boolean": return String(b);
                default: if (b === u) return "null"; if (b instanceof Array) { var d = ["["], g = b.length, l, k, r; for (k = 0; k < g; k++)switch (r = b[k], typeof r) { case "undefined": case "function": case "unknown": break; default: l && d.push(","), d.push(mt.z.stringify(r)), l = 1 }d.push("]"); return d.join("") } if (b instanceof Date) return '"' + b.getFullYear() + "-" + a(b.getMonth() + 1) + "-" + a(b.getDate()) + "T" + a(b.getHours()) + ":" + a(b.getMinutes()) + ":" + a(b.getSeconds()) + '"'; l = ["{"]; k = mt.z.stringify; for (g in b) if (Object.prototype.hasOwnProperty.call(b, g)) switch (r =
                    b[g], typeof r) { case "undefined": case "unknown": case "function": break; default: d && l.push(","), d = 1, l.push(k(g) + ":" + k(r)) }l.push("}"); return l.join("")
            }
        }
    }(); mt.localStorage = {}; mt.localStorage.R = function () { if (!mt.localStorage.h) try { mt.localStorage.h = document.createElement("input"), mt.localStorage.h.type = "hidden", mt.localStorage.h.style.display = "none", mt.localStorage.h.addBehavior("#default#userData"), document.getElementsByTagName("head")[0].appendChild(mt.localStorage.h) } catch (e) { return v } return t };
    mt.localStorage.set = function (e, a, b) { var f = new Date; f.setTime(f.getTime() + (b || 31536E6)); try { window.localStorage ? (a = f.getTime() + "|" + a, window.localStorage.setItem(e, a)) : mt.localStorage.R() && (mt.localStorage.h.expires = f.toUTCString(), mt.localStorage.h.load(document.location.hostname), mt.localStorage.h.setAttribute(e, a), mt.localStorage.h.save(document.location.hostname)) } catch (d) { } };
    mt.localStorage.get = function (e) { if (window.localStorage) { if (e = window.localStorage.getItem(e)) { var a = e.indexOf("|"), b = e.substring(0, a) - 0; if (b && b > (new Date).getTime()) return e.substring(a + 1) } } else if (mt.localStorage.R()) try { return mt.localStorage.h.load(document.location.hostname), mt.localStorage.h.getAttribute(e) } catch (f) { } return u };
    mt.localStorage.remove = function (e) { if (window.localStorage) window.localStorage.removeItem(e); else if (mt.localStorage.R()) try { mt.localStorage.h.load(document.location.hostname), mt.localStorage.h.removeAttribute(e), mt.localStorage.h.save(document.location.hostname) } catch (a) { } }; mt.sessionStorage = {}; mt.sessionStorage.set = function (e, a) { try { window.sessionStorage && window.sessionStorage.setItem(e, a) } catch (b) { } };
    mt.sessionStorage.get = function (e) { try { return window.sessionStorage ? window.sessionStorage.getItem(e) : u } catch (a) { return u } }; mt.sessionStorage.remove = function (e) { try { window.sessionStorage && window.sessionStorage.removeItem(e) } catch (a) { } };
    (function () {
        var e = mt.z; mt.B = {}; mt.B.log = function (a, b) { var f = new Image, d = "mini_tangram_log_" + Math.floor(2147483648 * Math.random()).toString(36); window[d] = f; f.onload = function () { f.onload = u; f = window[d] = u; b && b(a) }; f.src = a }; mt.B.get = function (a, b) { return mt.B.xa({ url: a, method: "GET", data: b.data, timeout: b.timeout, noCache: t, success: b.success, fail: b.fail }) }; mt.B.xa = function (a) {
            function b(b) {
                var m = a[b]; if (m) if (q && clearTimeout(q), "success" !== b) m && m(n); else {
                    var d; try { d = e.parse(n.responseText) } catch (f) { m && m(n); return } m &&
                        m(n, d)
                }
            } a = a || {}; var f = function (a) { var b = [], m; for (m in a) a.hasOwnProperty(m) && b.push(encodeURIComponent(m) + "=" + encodeURIComponent(a[m])); return b.join("&") }(a.data || {}), d = a.url, g = (a.method || "GET").toUpperCase(), l = a.headers || {}, k = a.timeout || 0, r = a.noCache || v, n, q; try {
                a: if (window.XMLHttpRequest) n = new XMLHttpRequest; else { try { n = new ActiveXObject("Microsoft.XMLHTTP"); break a } catch (p) { } n = s } "GET" === g && (f && (d += (0 <= d.indexOf("?") ? "&" : "?") + f, f = u), r && (d += (0 <= d.indexOf("?") ? "&" : "?") + "b" + +new Date + "=1")); n.open(g,
                    d, t); n.onreadystatechange = function () { if (4 === n.readyState) { var a = 0; try { a = n.status } catch (m) { b("fail"); return } 200 <= a && 300 > a || 304 === a || 1223 === a ? b("success") : b("fail") } }; for (var m in l) l.hasOwnProperty(m) && n.setRequestHeader(m, l[m]); k && (q = setTimeout(function () { n.onreadystatechange = function () { }; n.abort(); b("fail") }, k)); n.send(f)
            } catch (w) { b("fail") } return n
        }; return mt.B
    })();
    h.s = {
        lb: "http://tongji.baidu.com/hm-web/welcome/ico", ba: "hm.baidu.com/hm.gif", ya: /^(tongji|hmcdn).baidu.com$/, Hb: "tongji.baidu.com", ib: "hmmd", jb: "hmpl", Kb: "utm_medium", hb: "hmkw", Mb: "utm_term", fb: "hmci", Jb: "utm_content", kb: "hmsr", Lb: "utm_source", gb: "hmcu", Ib: "utm_campaign", la: 0, C: Math.round(+new Date / 1E3), protocol: "https:" === document.location.protocol ? "https:" : "http:", M: "https:", Da: 6E5, bc: 5E3, Ea: 5, ea: 1024, H: 2147483647, sa: "hca cc cf ci ck cl cm cp cu cw ds vl ep et ja ln lo lt rnd si su v cv lv api sn r ww p ct u tt".split(" "),
        ha: t, Qb: { id: "data-hm-id", Ub: "data-hm-class", ic: "data-hm-xpath", content: "data-hm-content", gc: "data-hm-tag", link: "data-hm-link" }, Sb: "data-hm-enabled", Rb: "data-hm-disabled", yb: "https://hmcdn.baidu.com/static/tongji/plugins/", oa: ["UrlChangeTracker"], Ob: { $b: 0, hc: 1, Yb: 2 }
    }; (function () { var e = { w: {}, c: function (a, b) { this.w[a] = this.w[a] || []; this.w[a].push(b) }, l: function (a, b) { this.w[a] = this.w[a] || []; for (var f = this.w[a].length, d = 0; d < f; d++)this.w[a][d](b) } }; return h.t = e })();
    (function () {
        var e = mt.lang, a = /^https?:\/\//, b = {
            Pa: function (a) { var b; try { b = JSON.parse(decodeURIComponent(a[0])) } catch (g) { } return b }, ma: function (a, d) { return b.na(h.b && h.b.a && h.b.a.u, a, d) || b.na(document.location.href, a, d) }, na: function (b, d, g) { if (b === s) return v; a.test(d) || (b = b.replace(a, "")); d = d.replace(/\/$/, ""); b = b.replace(/\/$/, ""); g && (b = b.replace(/^(https?:\/\/)?www\./, "$1")); return RegExp("^" + d.replace(/[?.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*") + "$").test(b) }, I: function (a, d) {
                var g = b.Pa(a); if (!e.j(g,
                    "Undefined")) { if (e.isArray(g)) { for (var l = 0; l < g.length; l++)if (b.ma(g[l], d)) return t; return v } if (e.K(g)) { var l = [], k; for (k in g) g.hasOwnProperty(k) && b.ma(k, d) && (l = l.concat(g[k])); return l } }
            }
        }; return h.T = b
    })();
    (function () { function e(b, f) { var d = document.createElement("script"); d.charset = "utf-8"; a.k(f) && (d.readyState ? d.onreadystatechange = function () { if ("loaded" === d.readyState || "complete" === d.readyState) d.onreadystatechange = u, f() } : d.onload = function () { f() }); d.src = b; var g = document.getElementsByTagName("script")[0]; g.parentNode.insertBefore(d, g) } var a = mt.lang; return h.load = e })();
    (function () { var e = h.s, a = { F: function () { if ("" !== c.icon) { var a = c.icon.split("|"), f = e.lb + "?s=" + c.id, d = "https://hmcdn.baidu.com/static" + a[0] + ".gif"; document.write("swf" === a[1] || "gif" === a[1] ? '<a href="' + f + '" target="_blank"><img border="0" src="' + d + '" width="' + a[2] + '" height="' + a[3] + '"></a>' : '<a href="' + f + '" target="_blank">' + a[0] + "</a>") } } }; h.t.c("pv-b", a.F); return a })();
    (function () {
        var e = mt.url, a = mt.cookie, b = mt.localStorage, f = mt.sessionStorage, d = {
            getData: function (d) { try { return a.get(d) || f.get(d) || b.get(d) } catch (e) { } }, setData: function (g, e, k) { try { a.set(g, e, { domain: d.J(), path: d.V(), D: k }), k ? b.set(g, e, k) : f.set(g, e) } catch (r) { } }, removeData: function (g) { try { a.set(g, "", { domain: d.J(), path: d.V(), D: -1 }), f.remove(g), b.remove(g) } catch (e) { } }, J: function () {
                for (var a = document.location.hostname, b = 0, d = c.dm.length; b < d; b++)if (e.rb(a, c.dm[b])) return c.dm[b].replace(/(:\d+)?[/?#].*/, "");
                return a
            }, V: function () { for (var a = 0, b = c.dm.length; a < b; a++) { var d = c.dm[a]; if (-1 < d.indexOf("/") && e.qb(d)) return d.replace(/^[^/]+(\/.*)/, "$1") + "/" } return "/" }
        }; return h.S = d
    })();
    (function () {
        var e = mt.lang, a = mt.d, b = h.T, f = {
            Ha: function (d, e) { return function (l) { var k = l.target || l.srcElement; if (k) { var r = b.I(e) || [], n = k.getAttribute(d.Q); l = l.clientX + ":" + l.clientY; if (n && n === l) k.removeAttribute(d.Q); else if (0 < r.length && (k = a.Xa(k)) && k.length) if (r = k.length, n = k[k.length - 1], 1E4 > r * n.split(">").length) for (n = 0; n < r; n++)f.ra(d, k[n]); else f.ra(d, n) } } }, ra: function (a, b) { for (var f = {}, k = String(b).split(">").length, r = 0; r < k; r++)f[b] = "", b = b.substring(0, b.lastIndexOf(">")); a && (e.K(a) && a.da) && a.da(f) },
            Ab: function (a, b) { return function (f) { (f.target || f.srcElement).setAttribute(a.Q, f.clientX + ":" + f.clientY); a && a.O && (b ? a.O(b) : a.O("#" + encodeURIComponent(this.id), f.type)) } }
        }; return h.Ia = f
    })();
    (function () { var e = mt.d, a = mt.event, b = h.T, f = h.Ia, d = { Q: "HM_fix", va: function () { a.c(document, "click", f.Ha(d, c.etrk)); for (var g = b.I(c.etrk) || [], l = 0; l < g.length; l++) { var k = g[l]; -1 === k.indexOf(">") && (0 === k.indexOf("#") && (k = k.substring(1)), (k = e.Ma(k)) && a.c(k, "click", f.Ab(d))) } }, da: function (a) { for (var f = b.I(c.etrk) || [], e = 0; e < f.length; e++) { var r = f[e]; a.hasOwnProperty(r) && d.O(r) } }, O: function (a, b) { h.b.a.et = 1; h.b.a.ep = "{id:" + a + ",eventType:" + (b || "click") + "}"; h.b.n() } }; h.t.c("pv-b", d.va); return d })();
    (function () {
        var e = mt.d, a = mt.lang, b = mt.event, f = mt.e, d = h.s, g = h.T, l = [], k = {
            ua: function () { c.ctrk && 0 < c.ctrk.length && (b.c(document, "mouseup", k.Ca()), b.c(window, "unload", function () { k.N() }), setInterval(function () { k.N() }, d.Da)) }, Ca: function () {
                return function (a) {
                    if (g.I(c.ctrk, t) && (a = k.Oa(a), "" !== a)) {
                        var b = (d.M + "//" + d.ba + "?" + h.b.qa().replace(/ep=[^&]*/, "ep=" + encodeURIComponent(a))).length; b + (d.H + "").length > d.ea || (b + encodeURIComponent(l.join("!") + (l.length ? "!" : "")).length + (d.H + "").length > d.ea && k.N(), l.push(a),
                            (l.length >= d.Ea || /\*a\*/.test(a)) && k.N())
                    }
                }
            }, Oa: function (b) {
                var d = b.target || b.srcElement, g, l; f.nb ? (l = Math.max(document.documentElement.scrollTop, document.body.scrollTop), g = Math.max(document.documentElement.scrollLeft, document.body.scrollLeft), g = b.clientX + g, l = b.clientY + l) : (g = b.pageX, l = b.pageY); b = k.Ua(b, d, g, l); var m = window.innerWidth || document.documentElement.clientWidth || document.body.offsetWidth; switch (c.align) { case 1: g -= m / 2; break; case 2: g -= m }m = []; m.push(g); m.push(l); m.push(b.vb); m.push(b.wb); m.push(b.zb);
                m.push(a.g(b.xb)); m.push(b.Nb); m.push(b.eb); (d = "a" === (d.tagName || "").toLowerCase() ? d : e.Na(d)) ? (m.push("a"), m.push(a.g(encodeURIComponent(d.href)))) : m.push("b"); return m.join("*")
            }, Ua: function (b, d, g, l) {
                b = e.Ya(d); var m = 0, w = 0, x = 0, k = 0; if (d && (m = d.offsetWidth || d.clientWidth, w = d.offsetHeight || d.clientHeight, k = e.Va(d), x = k.left, k = k.top, a.k(d.getBBox) && (w = d.getBBox(), m = w.width, w = w.height), "html" === (d.tagName || "").toLowerCase())) m = Math.max(m, d.clientWidth), w = Math.max(w, d.clientHeight); return {
                    vb: Math.round(100 *
                        ((g - x) / m)), wb: Math.round(100 * ((l - k) / w)), zb: f.orientation, xb: b, Nb: m, eb: w
                }
            }, N: function () { 0 !== l.length && (h.b.a.et = 2, h.b.a.ep = l.join("!"), h.b.n(), l = []) }
        }; h.t.c("pv-b", k.ua); return k
    })();
    (function () {
        function e() { return function () { h.b.a.et = 3; h.b.a.ep = h.U.Wa() + "," + h.U.Sa(); h.b.a.hca = c.hca; h.b.n() } } function a() { clearTimeout(C); var b; x && (b = "visible" == document[x]); B && (b = !document[B]); k = "undefined" == typeof b ? t : b; if ((!l || !r) && k && n) w = t, p = +new Date; else if (l && r && (!k || !n)) w = v, m += +new Date - p; l = k; r = n; C = setTimeout(a, 100) } function b(a) { var b = document, m = ""; if (a in b) m = a; else for (var d = ["webkit", "ms", "moz", "o"], f = 0; f < d.length; f++) { var e = d[f] + a.charAt(0).toUpperCase() + a.slice(1); if (e in b) { m = e; break } } return m }
        function f(b) { if (!("focus" == b.type || "blur" == b.type) || !(b.target && b.target != window)) n = "focus" == b.type || "focusin" == b.type ? t : v, a() } var d = mt.event, g = h.t, l = t, k = t, r = t, n = t, q = +new Date, p = q, m = 0, w = t, x = b("visibilityState"), B = b("hidden"), C; a(); (function () {
            var b = x.replace(/[vV]isibilityState/, "visibilitychange"); d.c(document, b, a); d.c(window, "pageshow", a); d.c(window, "pagehide", a); "object" == typeof document.onfocusin ? (d.c(document, "focusin", f), d.c(document, "focusout", f)) : (d.c(window, "focus", f), d.c(window, "blur",
                f))
        })(); h.U = { Wa: function () { return +new Date - q }, Sa: function () { return w ? +new Date - p + m : m } }; g.c("pv-b", function () { d.c(window, "unload", e()) }); g.c("duration-send", e()); g.c("duration-done", function () { p = q = +new Date; m = 0 }); return h.U
    })();
    (function () { var e = mt.lang, a = h.s, b = h.load, f = h.S, d = { mb: function (d) { if ((window._dxt === s || e.j(window._dxt, "Array")) && "undefined" !== typeof h.b) { var l = f.J(); b([a.protocol, "//datax.baidu.com/x.js?si=", c.id, "&dm=", encodeURIComponent(l)].join(""), d) } }, Gb: function (a) { if (e.j(a, "String") || e.j(a, "Number")) window._dxt = window._dxt || [], window._dxt.push(["_setUserId", a]) } }; return h.Fa = d })();
    (function () {
        function e(a, b, d, f) { if (!(a === s || b === s || f === s)) { if ("" === a) return [b, d, f].join("*"); a = String(a).split("!"); for (var e, g = v, k = 0; k < a.length; k++)if (e = a[k].split("*"), String(b) === e[0]) { e[1] = d; e[2] = f; a[k] = e.join("*"); g = t; break } g || a.push([b, d, f].join("*")); return a.join("!") } } function a(b) { for (var d in b) if ({}.hasOwnProperty.call(b, d)) { var e = b[d]; f.K(e) || f.isArray(e) ? a(e) : b[d] = String(e) } } var b = mt.url, f = mt.lang, d = mt.z, g = mt.e, l = h.s, k = h.t, r = h.Fa, n = h.load, q = h.S, p = {
            G: [], P: 0, Z: v, o: { ca: "", page: "" }, F: function () {
                p.i =
                0; k.c("pv-b", function () { p.Ga(); p.Ja() }); k.c("pv-d", function () { p.Ka(); p.o.page = "" }); k.c("stag-b", function () { h.b.a.api = p.i || p.P ? p.i + "_" + p.P : ""; h.b.a.ct = [decodeURIComponent(q.getData("Hm_ct_" + c.id) || ""), p.o.ca, p.o.page].join("!") }); k.c("stag-d", function () { h.b.a.api = 0; p.i = 0; p.P = 0 })
            }, Ga: function () {
                var a = window._hmt || []; if (!a || f.j(a, "Array")) window._hmt = {
                    id: c.id, cmd: {}, push: function () {
                        for (var a = window._hmt, b = 0; b < arguments.length; b++) {
                            var d = arguments[b]; f.j(d, "Array") && (a.cmd[a.id].push(d), "_setAccount" ===
                                d[0] && (1 < d.length && /^[0-9a-f]{31,32}$/.test(d[1])) && (d = d[1], a.id = d, a.cmd[d] = a.cmd[d] || []))
                        }
                    }
                }, window._hmt.cmd[c.id] = [], window._hmt.push.apply(window._hmt, a)
            }, Ja: function () { var a = window._hmt; if (a && a.cmd && a.cmd[c.id]) for (var b = a.cmd[c.id], d = /^_track(Event|Order)$/, f = 0, e = b.length; f < e; f++) { var g = b[f]; d.test(g[0]) ? p.G.push(g) : p.aa(g) } a.cmd[c.id] = { push: p.aa } }, Ka: function () { if (0 < p.G.length) for (var a = 0, b = p.G.length; a < b; a++)p.aa(p.G[a]); p.G = u }, aa: function (a) { var b = a[0]; if (p.hasOwnProperty(b) && f.k(p[b])) p[b](a) },
            _setAccount: function (a) { 1 < a.length && /^[0-9a-f]{31,32}$/.test(a[1]) && (p.i |= 1) }, _setAutoPageview: function (a) { if (1 < a.length && (a = a[1], v === a || t === a)) p.i |= 2, h.b.ia = a }, _trackPageview: function (a) { 1 < a.length && (a[1].charAt && "/" === a[1].charAt(0)) && (p.i |= 4, h.b.a.sn = h.b.fa(), h.b.a.et = 0, h.b.a.ep = "", h.b.a.vl = g.X(), p.Z || (h.b.a.su = h.b.a.u || document.location.href), h.b.a.u = l.protocol + "//" + document.location.host + a[1], h.b.n(), h.b.tb = +new Date) }, _trackEvent: function (a) {
                2 < a.length && (p.i |= 8, h.b.a.et = 4, h.b.a.ep = f.g(a[1]) +
                    "*" + f.g(a[2]) + (a[3] ? "*" + f.g(a[3]) : "") + (a[4] ? "*" + f.g(a[4]) : ""), h.b.n())
            }, _setCustomVar: function (a) { if (!(4 > a.length)) { var b = a[1], d = a[4] || 3; if (0 < b && 6 > b && 0 < d && 4 > d) { p.P++; for (var e = (h.b.a.cv || "*").split("!"), g = e.length; g < b - 1; g++)e.push("*"); e[b - 1] = d + "*" + f.g(a[2]) + "*" + f.g(a[3]); h.b.a.cv = e.join("!"); a = h.b.a.cv.replace(/[^1](\*[^!]*){2}/g, "*").replace(/((^|!)\*)+$/g, ""); "" !== a ? q.setData("Hm_cv_" + c.id, encodeURIComponent(a), c.age) : q.removeData("Hm_cv_" + c.id) } } }, _setUserTag: function (a) {
                if (!(3 > a.length)) {
                    var b =
                        f.g(a[1]); a = f.g(a[2]); if (b !== s && a !== s) { var d = decodeURIComponent(q.getData("Hm_ct_" + c.id) || ""), d = e(d, b, 1, a); q.setData("Hm_ct_" + c.id, encodeURIComponent(d), c.age) }
                }
            }, _setVisitTag: function (a) { if (!(3 > a.length)) { var b = f.g(a[1]); a = f.g(a[2]); if (b !== s && a !== s) { var d = p.o.ca, d = e(d, b, 2, a); p.o.ca = d } } }, _setPageTag: function (a) { if (!(3 > a.length)) { var b = f.g(a[1]); a = f.g(a[2]); if (b !== s && a !== s) { var d = p.o.page, d = e(d, b, 3, a); p.o.page = d } } }, _setReferrerOverride: function (a) {
                1 < a.length && (a = a[1], f.j(a, "String") ? (h.b.a.su = "/" ===
                    a.charAt(0) ? l.protocol + "//" + window.location.host + a : a, p.Z = t) : p.Z = v)
            }, _trackOrder: function (b) { b = b[1]; f.K(b) && (a(b), p.i |= 16, h.b.a.et = 94, h.b.a.ep = d.stringify(b), h.b.n()) }, _setDataxId: function (a) { a = a[1]; r.mb(); r.Gb(a) }, _setAutoTracking: function (a) { if (1 < a.length && (a = a[1], v === a || t === a)) h.b.ka = a }, _trackPageDuration: function (a) { 1 < a.length ? (a = a[1], 2 === String(a).split(",").length && (h.b.a.et = 3, h.b.a.ep = a, h.b.n())) : k.l("duration-send"); k.l("duration-done") }, _require: function (a) {
                1 < a.length && (a = a[1], l.ya.test(b.W(a)) &&
                    n(a))
            }, _providePlugin: function (a) { if (1 < a.length) { var b = window._hmt, d = a[1]; a = a[2]; if (f.Y(l.oa, d) && f.k(a) && (b.plugins = b.plugins || {}, b.A = b.A || {}, b.plugins[d] = a, b.m = b.m || [], a = b.m.slice(), d && a.length && a[0][1] === d)) for (var e = 0, g = a.length; e < g; e++) { var k = a[e][2] || {}; if (b.plugins[d] && !b.A[d]) b.A[d] = new b.plugins[d](k), b.m.shift(); else break } } }, _requirePlugin: function (a) {
                if (1 < a.length) {
                    var b = window._hmt, d = a[1], e = a[2] || {}; if (f.Y(l.oa, d)) if (b.plugins = b.plugins || {}, b.A = b.A || {}, b.plugins[d] && !b.A[d]) b.A[d] = new b.plugins[d](e);
                    else { b.m = b.m || []; for (var e = 0, g = b.m.length; e < g; e++)if (b.m[e][1] === d) return; b.m.push(a); p._require([u, l.yb + d + ".js"]) }
                }
            }
        }; p.F(); h.za = p; return h.za
    })(); (function () { var e = h.t; c.spa !== s && "1" === String(c.spa) && (window._hmt = window._hmt || [], window._hmt.push(["_requirePlugin", "UrlChangeTracker"]), e.c("pv-b", function () { "" !== window.location.hash && (h.b.a.u = window.location.href) })) })();
    (function () {
        function e() { "undefined" === typeof window["_bdhm_loaded_" + c.id] && (window["_bdhm_loaded_" + c.id] = t, this.a = {}, this.pb = this.ka = this.ia = t, this.ha = q.ha, this.Tb = f.$(c.aet) && 0 < c.aet.length ? c.aet.split(",") : "", this.F()) } var a = mt.url, b = mt.B, f = mt.lang, d = mt.cookie, g = mt.e, l = mt.sessionStorage, k = mt.z, r = mt.event, n = h.S, q = h.s, p = h.load, m = h.t; e.prototype = {
            Eb: function () {
                var a, b, f, e; q.la = n.getData("Hm_lpvt_" + c.id) || 0; if (e = n.getData("Hm_lvt_" + c.id)) {
                    for (b = e.split(","); 2592E3 < q.C - b[0];)b.shift(); f = 4 > b.length ?
                        2 : 3; for (q.C - q.la > c.vdur && b.push(q.C); 4 < b.length;)b.shift(); e = b.join(","); b = b[b.length - 1]
                } else e = q.C, b = "", f = 1; this.ob() ? (n.setData("Hm_lvt_" + c.id, e, c.age), n.setData("Hm_lpvt_" + c.id, q.C), a = d.sb(n.J(), n.V())) : this.La(); this.a.cc = a; this.a.lt = b; this.a.lv = f
            }, ob: function () { var b = a.W(document.location.href); return !f.Y("sjh.baidu.com isite.baidu.com ls.wejianzhan.com bs.wejianzhan.com product.weijianzhan.com qianhu.weijianzhan.com aisite.wejianzhan.com".split(" "), b) }, La: function () {
                for (var a = document.cookie.split(";"),
                    b = 0; b < a.length; b++) { var d = a[b].split("="); d.length && /Hm_(up|ct|cv|lp?vt)_[0-9a-f]{31}/.test(String(d[0])) && n.removeData(d[0]); d.length && /Hm_ck_[0-9]{13}/.test(String(d[0])) && n.removeData(d[0]) }
            }, qa: function () { for (var a = [], b = this.a.et, d = 0, f = q.sa.length; d < f; d++) { var e = q.sa[d], g = this.a[e]; "undefined" !== typeof g && "" !== g && ("tt" !== e || "tt" === e && 0 === b) && ("ct" !== e || "ct" === e && 0 === b) && a.push(e + "=" + encodeURIComponent(g)) } return a.join("&") }, Fb: function () {
                this.Eb(); this.a.si = c.id; this.a.sn = this.fa(); this.a.su =
                    document.referrer; this.a.ds = g.Bb; this.a.cl = g.colorDepth + "-bit"; this.a.ln = String(g.language).toLowerCase(); this.a.ja = g.javaEnabled ? 1 : 0; this.a.ck = g.cookieEnabled ? 1 : 0; this.a.lo = "number" === typeof _bdhm_top ? 1 : 0; this.a.v = "1.2.94"; this.a.cv = decodeURIComponent(n.getData("Hm_cv_" + c.id) || ""); this.a.tt = document.title || ""; this.a.vl = g.X(); var b = document.location.href; this.a.cm = a.f(b, q.ib) || ""; this.a.cp = a.f(b, q.jb) || a.f(b, q.Kb) || ""; this.a.cw = a.f(b, q.hb) || a.f(b, q.Mb) || ""; this.a.ci = a.f(b, q.fb) || a.f(b, q.Jb) || ""; this.a.cf =
                        a.f(b, q.kb) || a.f(b, q.Lb) || ""; this.a.cu = a.f(b, q.gb) || a.f(b, q.Ib) || ""; /https?:/.test(document.location.protocol) && (this.a.u = b)
            }, F: function () { try { this.Fb(), this.Db(), h.b = this, this.Aa(), this.ub(), m.l("pv-b"), this.pb && this.Cb() } catch (a) { var d = []; d.push("si=" + c.id); d.push("n=" + encodeURIComponent(a.name)); d.push("m=" + encodeURIComponent(a.message)); d.push("r=" + encodeURIComponent(document.referrer)); b.log(q.M + "//" + q.ba + "?" + d.join("&")) } }, Cb: function () {
                function a() { m.l("pv-d") } this.ia ? (this.a.et = 0, this.a.ep =
                    "", m.l("setPageviewProp"), this.a.vl = g.X(), this.n(a), this.a.p = "") : a(); this.tb = +new Date; m.l("clearPageviewProp")
            }, n: function (a) { if (this.ka) { var d = this; d.a.rnd = Math.round(Math.random() * q.H); d.a.r = g.orientation; d.a.ww = g.ta; m.l("stag-b"); var e = q.M + "//" + q.ba + "?" + d.qa(); m.l("stag-d"); d.wa(e); b.log(e, function (b) { d.pa(b); f.k(a) && a.call(d) }) } }, Aa: function () {
                try {
                    if (window.postMessage && window.self !== window.parent) {
                        var b = this; r.c(window, "message", function (d) {
                            if (a.W(d.origin) === q.Hb) {
                                d = d.data || {}; var e = d.jn ||
                                    "", f = /^customevent$|^heatmap$|^pageclick$|^select$/.test(e); if (RegExp(c.id).test(d.sd || "") && f) b.a.rnd = Math.round(Math.random() * q.H), p(q.protocol + "//" + c.js + e + ".js?" + b.a.rnd)
                            }
                        }); window.parent.postMessage({ id: c.id, url: document.location.href, status: "__Messenger__hmLoaded" }, "*")
                    }
                } catch (d) { }
            }, ub: function () {
                try {
                    if (window.self === window.parent) {
                        var b = document.location.href, d = a.f(b, "baidu-analytics-token"), e = a.f(b, "baidu-analytics-jn"); /^[a-f0-9]{32}\/?$/.test(d) && /^(overlay|vabtest)\/?$/.test(e) && p(q.protocol +
                            "//" + c.js + e + ".js?" + Math.round(Math.random() * q.H))
                    }
                } catch (f) { }
            }, wa: function (a) { var b; try { b = k.parse(l.get("Hm_unsent_" + c.id) || "[]") } catch (d) { b = [] } var e = this.a.u ? "" : "&u=" + encodeURIComponent(document.location.href); b.push(a.replace(/^https?:\/\//, "") + e); l.set("Hm_unsent_" + c.id, k.stringify(b)) }, pa: function (a) {
                var b; try { b = k.parse(l.get("Hm_unsent_" + c.id) || "[]") } catch (d) { b = [] } if (b.length) {
                    a = a.replace(/^https?:\/\//, ""); for (var e = 0; e < b.length; e++)if (a.replace(/&u=[^&]*/, "") === b[e].replace(/&u=[^&]*/, "")) {
                        b.splice(e,
                            1); break
                    } b.length ? l.set("Hm_unsent_" + c.id, k.stringify(b)) : this.Ba()
                }
            }, Ba: function () { l.remove("Hm_unsent_" + c.id) }, Db: function () { var a = this, d; try { d = k.parse(l.get("Hm_unsent_" + c.id) || "[]") } catch (e) { d = [] } if (d.length) for (var f = function (d) { b.log(q.M + "//" + d, function (b) { a.pa(b) }) }, g = 0; g < d.length; g++)f(d[g]) }, fa: function () { return Math.round(+new Date / 1E3) % 65535 }
        }; return new e
    })(); var y = h.s, z = h.load; if (c.apps) { var A = [y.protocol, "//ers.baidu.com/app/s.js?"]; A.push(c.apps); z(A.join("")) } var D = h.s, E = h.load;
    c.pt && E([D.protocol, "//ada.baidu.com/phone-tracker/insert_bdtj?sid=", c.pt].join("")); var F = h.load; if (c.qiao) { for (var G = ["https://goutong.baidu.com/site/"], H = c.id, I = 5381, J = H.length, K = 0; K < J; K++)I = (33 * I + Number(H.charCodeAt(K))) % 4294967296; 2147483648 < I && (I -= 2147483648); G.push(I % 1E3 + "/"); G.push(c.id + "/b.js"); G.push("?siteId=" + c.qiao); F(G.join("")) };
})();
